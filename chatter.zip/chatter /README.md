## Update Info

# Date:- 26 Apr 2024

# Added Files

- banner_ad.dart
- interstitial_manager.dart
- firebase_notification_manager.dart
- subscription_manager.dart

# Note

- notififcation_service.dart Renamed to ---- notification_service.dart

# Modified Files

- add_post_controller.dart
- const.dart
- content_full_screen.dart
- feed_screen.dart
- invitations_model.dart
- languages.dart
- notification_screen.dart
- notification_service.dart
- Podfile.lock
- post_card.dart
- post_controller.dart
- profile_screen.dart
- profile_verification_controller.dart
- profile_verification_screen.dart
- pubspec.lock
- pubspec.yaml
- result_view.dart
- room_invitation_screen.dart
- username_controller.dart
- username_screen.dart
- video_player_sheet.dart
- session_manager.dart
- setting_controller.dart
- setting_screen.dart
- splash_controller.dart
- story.dart
- story_screen_controller.dart
- story_service.dart
- tabbar_screen.dart
- user_service.dart
- random_screen.dart
- registration.dart
- report_controller.dart
- camera_filters.dart
- chat_tag.dart
- chatting_controller.dart
- comment_card.dart
- comment_controller.dart
- edit_profile_controller.dart
- edit_profile_screen.dart
- feed_stories_controller.dart
- firebase_notification_manager.dart
- int_extension.dart
- interests_controller.dart
- languages_controller.dart
- login_controller.dart
- main.dart
- my_cached_image.dart
- AndroidManifest.xml
- banner_ad.dart
- interstitial_manager.dart
- room_controller.dart
- room_member_model.dart
- room_menu.dart
- add_post_screen.dart
- back_button.dart
- English.dart
- feed_story_screen.dart
- Russian.dart
- Spanish.dart
- Thai.dart
- Turkish.dart
- Vietnamese.dart
- build.gradle
- Danish.dart
- Double_click_like.dart
- Dutch.dart
- Finnish.dart
- French.dart
- German.dart
- Greek.dart
- Hindi.dart
- Indonesian.dart
- Italian.dart
- Japanese.dart
- Korean.dart
- Norwegian.dart
- Polish.dart
- Portuguese.dart
- Notification_service.dart
- Arabic.dart
- Chinese.dart
- Create_room_controller.dart
- Hebrew.dart
- Malay.dart
- Swedish.dart
- Norwegian.dart
  =============================================