package com.retrytech.chatter.untitled

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
