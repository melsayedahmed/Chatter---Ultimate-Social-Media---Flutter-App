

enum StatusBarStyle { white, black }

class Functions {
  static void changStatusBar(StatusBarStyle style) {
    // SystemChrome.setSystemUIOverlayStyle((style == StatusBarStyle.white)
    //     ? SystemUiOverlayStyle.light
    //     : SystemUiOverlayStyle.dark);
  }
}
